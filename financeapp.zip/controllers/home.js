exports.getHome = (req, res) => {
    res.status(200).send("Finance Project!");
}